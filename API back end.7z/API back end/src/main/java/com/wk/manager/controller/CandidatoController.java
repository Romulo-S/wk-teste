package com.wk.manager.controller;

import com.wk.manager.models.Candidato;
import com.wk.manager.repository.CandidatoRepository;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping(value = "/api")
@CrossOrigin(origins = "http://localhost:8081")
@Api(value="API REST Produtos")
public class CandidatoController {

    @Autowired
    private CandidatoRepository candidatoRepository;

    @ApiOperation(value="Retorna uma lista de Candidatos")
    @GetMapping("/candidatos")
    public List<Candidato> listaCandidatos(){
        return candidatoRepository.findAll();
    }

    @ApiOperation(value="Retorna um Candidato unico")
    @GetMapping("/candidato/{id}")
    public Candidato listaCandidatoUnico(@PathVariable(value="id") long id){
        return candidatoRepository.findById(id).get();
    }

    @ApiOperation(value="Salva um Candidato")
    @PostMapping("/candidato")
    public Candidato salvaCandidato(@RequestBody @Valid Candidato Candidato) {
        return candidatoRepository.save(Candidato);
    }

    @ApiOperation(value="Deleta um Candidato")
    @DeleteMapping("/Candidato")
    public void deletaCandidato(@RequestBody @Valid Candidato Candidato) {
        candidatoRepository.delete(Candidato);
    }

    @ApiOperation(value="Atualiza um Candidato")
    @PutMapping("/Candidato")
    public Candidato atualizaCandidato(@RequestBody @Valid Candidato Candidato) {
        return candidatoRepository.save(Candidato);
    }

    //read json file to database
    public Iterable<Candidato> saveList(List<Candidato> candidatoList){
      return  candidatoRepository.saveAll(candidatoList);
    }
}
